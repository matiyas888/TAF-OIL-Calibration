<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Tables & Lookups - TAF Oil Ethiopia</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .access-table-th {
            @apply px-3 py-2 text-left text-[11px] font-bold text-slate-700 uppercase bg-slate-100 border-b border-slate-300;
        }
        .access-table-td {
            @apply px-3 py-2 text-xs border-b border-slate-200 text-slate-800;
        }
    </style>
</head>
<body class="bg-slate-200 min-h-screen text-slate-800 font-sans antialiased p-3 md:p-6">

    <div class="max-w-7xl mx-auto space-y-4">

        <!-- Top Navigation Bar -->
        <div class="bg-slate-900 text-white px-4 py-3 rounded-lg shadow flex flex-col sm:flex-row justify-between items-center gap-3">
            <div class="flex items-center space-x-3">
                <i class="fa-solid fa-database text-amber-400 text-lg"></i>
                <div>
                    <h1 class="text-sm font-black uppercase tracking-wider text-amber-400">TAF OIL ETHIOPIA - PETROLEUM DATABASE TABLES</h1>
                    <p class="text-[11px] text-slate-400">Reverse-engineered MS Access SQLite Database Structure & Lookups</p>
                </div>
            </div>
            <div class="flex items-center space-x-2">
                <a href="{{ route('petroleum.index') }}" class="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded font-bold text-xs flex items-center space-x-1 shadow transition">
                    <i class="fa-solid fa-arrow-left mr-1"></i>
                    <span>Back to Transhipment Order UI</span>
                </a>
            </div>
        </div>

        <!-- Table Selector Tabs -->
        <div class="bg-white p-2 rounded-lg shadow-sm border border-slate-300 flex flex-wrap gap-1.5 text-xs">
            <a href="?table=truck_headers"
                class="px-3 py-2 rounded font-bold flex items-center space-x-1.5 transition {{ $activeTable === 'truck_headers' ? 'bg-amber-600 text-white shadow' : 'bg-slate-100 hover:bg-slate-200 text-slate-700' }}">
                <i class="fa-solid fa-truck"></i>
                <span>truck_headers</span>
                <span class="ml-1 px-1.5 py-0.2 rounded-full text-[10px] {{ $activeTable === 'truck_headers' ? 'bg-amber-800 text-white' : 'bg-slate-300 text-slate-700' }}">
                    {{ $tableCounts['truck_headers'] }}
                </span>
            </a>

            <a href="?table=truck_calibrations"
                class="px-3 py-2 rounded font-bold flex items-center space-x-1.5 transition {{ $activeTable === 'truck_calibrations' ? 'bg-amber-600 text-white shadow' : 'bg-slate-100 hover:bg-slate-200 text-slate-700' }}">
                <i class="fa-solid fa-ruler"></i>
                <span>truck_calibrations</span>
                <span class="ml-1 px-1.5 py-0.2 rounded-full text-[10px] {{ $activeTable === 'truck_calibrations' ? 'bg-amber-800 text-white' : 'bg-slate-300 text-slate-700' }}">
                    {{ $tableCounts['truck_calibrations'] }}
                </span>
            </a>

            <a href="?table=allowable_loss_products"
                class="px-3 py-2 rounded font-bold flex items-center space-x-1.5 transition {{ $activeTable === 'allowable_loss_products' ? 'bg-amber-600 text-white shadow' : 'bg-slate-100 hover:bg-slate-200 text-slate-700' }}">
                <i class="fa-solid fa-gas-pump"></i>
                <span>allowable_loss_products</span>
                <span class="ml-1 px-1.5 py-0.2 rounded-full text-[10px] {{ $activeTable === 'allowable_loss_products' ? 'bg-amber-800 text-white' : 'bg-slate-300 text-slate-700' }}">
                    {{ $tableCounts['allowable_loss_products'] }}
                </span>
            </a>

            <a href="?table=transfer_orders"
                class="px-3 py-2 rounded font-bold flex items-center space-x-1.5 transition {{ $activeTable === 'transfer_orders' ? 'bg-amber-600 text-white shadow' : 'bg-slate-100 hover:bg-slate-200 text-slate-700' }}">
                <i class="fa-solid fa-file-invoice"></i>
                <span>transfer_orders</span>
                <span class="ml-1 px-1.5 py-0.2 rounded-full text-[10px] {{ $activeTable === 'transfer_orders' ? 'bg-amber-800 text-white' : 'bg-slate-300 text-slate-700' }}">
                    {{ $tableCounts['transfer_orders'] }}
                </span>
            </a>

            <a href="?table=density_correct_20"
                class="px-3 py-2 rounded font-bold flex items-center space-x-1.5 transition {{ $activeTable === 'density_correct_20' ? 'bg-amber-600 text-white shadow' : 'bg-slate-100 hover:bg-slate-200 text-slate-700' }}">
                <i class="fa-solid fa-temperature-half"></i>
                <span>density_correct_20</span>
                <span class="ml-1 px-1.5 py-0.2 rounded-full text-[10px] {{ $activeTable === 'density_correct_20' ? 'bg-amber-800 text-white' : 'bg-slate-300 text-slate-700' }}">
                    {{ $tableCounts['density_correct_20'] }}
                </span>
            </a>

            <a href="?table=factor_correct_20"
                class="px-3 py-2 rounded font-bold flex items-center space-x-1.5 transition {{ $activeTable === 'factor_correct_20' ? 'bg-amber-600 text-white shadow' : 'bg-slate-100 hover:bg-slate-200 text-slate-700' }}">
                <i class="fa-solid fa-chart-line"></i>
                <span>factor_correct_20</span>
                <span class="ml-1 px-1.5 py-0.2 rounded-full text-[10px] {{ $activeTable === 'factor_correct_20' ? 'bg-amber-800 text-white' : 'bg-slate-300 text-slate-700' }}">
                    {{ $tableCounts['factor_correct_20'] }}
                </span>
            </a>
        </div>

        <!-- Table Content Card -->
        <div class="bg-white rounded-lg shadow border border-slate-300 overflow-hidden">

            <!-- 1. TRUCK HEADERS -->
            @if($activeTable === 'truck_headers')
                <div class="p-3 bg-slate-100 border-b border-slate-200 flex justify-between items-center text-xs">
                    <div>
                        <strong class="text-slate-800 text-sm">Table: truck_headers</strong>
                        <span class="text-slate-500 ml-2">(MS Access legacy: <code>tblmaintbl_truck</code>)</span>
                    </div>
                    <span class="text-slate-600 font-mono font-semibold">{{ $trucks->count() }} registered vehicles</span>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-slate-200">
                        <thead>
                            <tr>
                                <th class="access-table-th">Plate No</th>
                                <th class="access-table-th">Truck No</th>
                                <th class="access-table-th">Trailer Plate</th>
                                <th class="access-table-th">Carrier / Transporter</th>
                                <th class="access-table-th">Assigned Driver</th>
                                <th class="access-table-th">Licence No</th>
                                <th class="access-table-th text-center">Comps</th>
                                <th class="access-table-th text-right">Capacity (L)</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            @foreach($trucks as $t)
                                <tr class="hover:bg-amber-50/50">
                                    <td class="access-table-td font-mono font-bold text-slate-900">{{ $t->plate_no }}</td>
                                    <td class="access-table-td font-mono">{{ $t->truck_no ?: '-' }}</td>
                                    <td class="access-table-td font-mono">{{ $t->trailer_plate_no ?: '-' }}</td>
                                    <td class="access-table-td font-semibold text-slate-700">
                                        <span class="px-2 py-0.5 rounded text-[11px] {{ str_contains($t->carrier_name, 'TAF') ? 'bg-indigo-100 text-indigo-800 font-bold' : 'bg-slate-100 text-slate-800' }}">
                                            {{ $t->carrier_name }}
                                        </span>
                                    </td>
                                    <td class="access-table-td font-bold text-slate-900">{{ $t->driver_name }}</td>
                                    <td class="access-table-td font-mono text-slate-600">{{ $t->driver_licence_no }}</td>
                                    <td class="access-table-td text-center font-mono">{{ $t->compartment_count }}</td>
                                    <td class="access-table-td text-right font-mono font-bold text-slate-900">{{ number_format($t->total_capacity, 0) }} L</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @endif

            <!-- 2. TRUCK CALIBRATIONS -->
            @if($activeTable === 'truck_calibrations')
                <div class="p-3 bg-slate-100 border-b border-slate-200 flex justify-between items-center text-xs">
                    <div>
                        <strong class="text-slate-800 text-sm">Table: truck_calibrations</strong>
                        <span class="text-slate-500 ml-2">(MS Access legacy: <code>tblsubtbl_truck</code>)</span>
                    </div>
                    <span class="text-slate-600 font-mono font-semibold">{{ $calibrations->count() }} calibration points</span>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-slate-200">
                        <thead>
                            <tr>
                                <th class="access-table-th">Truck Plate</th>
                                <th class="access-table-th text-center">Compartment No</th>
                                <th class="access-table-th text-right">Dip Measurement (mm)</th>
                                <th class="access-table-th text-right">Volume (Litres)</th>
                                <th class="access-table-th">Interpolation Formula</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 font-mono">
                            @foreach($calibrations as $c)
                                <tr class="hover:bg-amber-50/50">
                                    <td class="access-table-td font-bold text-slate-900">{{ $c->plate_no }}</td>
                                    <td class="access-table-td text-center">
                                        <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-200 text-slate-800">
                                            Comp {{ $c->compartment_no }}
                                        </span>
                                    </td>
                                    <td class="access-table-td text-right font-bold text-amber-700">{{ $c->dip_mm }} mm</td>
                                    <td class="access-table-td text-right font-bold text-emerald-700">{{ number_format($c->litres, 0) }} L</td>
                                    <td class="access-table-td text-[11px] text-slate-500 font-sans">
                                        Straight-line linear interpolation: round(y0 + (x - x0) / (x1 - x0) * (y1 - y0))
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @endif

            <!-- 3. PRODUCTS & ALLOWABLE LOSS -->
            @if($activeTable === 'allowable_loss_products')
                <div class="p-3 bg-slate-100 border-b border-slate-200 flex justify-between items-center text-xs">
                    <div>
                        <strong class="text-slate-800 text-sm">Table: allowable_loss_products</strong>
                        <span class="text-slate-500 ml-2">(MS Access legacy: <code>TBLALLOWABLE_LOSS_PRODUCT</code> & <code>_1</code>)</span>
                    </div>
                    <span class="text-slate-600 font-mono font-semibold">{{ $products->count() }} fuel products</span>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-slate-200">
                        <thead>
                            <tr>
                                <th class="access-table-th">Product Code</th>
                                <th class="access-table-th">Product Name</th>
                                <th class="access-table-th text-right">Allowable Loss %</th>
                                <th class="access-table-th text-right">Price per Litre (ETB)</th>
                                <th class="access-table-th text-right">Opening Balance</th>
                                <th class="access-table-th text-right">Pipeline Stock</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            @foreach($products as $p)
                                <tr class="hover:bg-amber-50/50">
                                    <td class="access-table-td font-mono font-bold text-indigo-900">{{ $p->item_number }}</td>
                                    <td class="access-table-td font-bold text-slate-900">{{ $p->product_name }}</td>
                                    <td class="access-table-td text-right font-mono font-bold text-emerald-700">
                                        {{ number_format($p->allowable_loss_percent, 2) }}%
                                    </td>
                                    <td class="access-table-td text-right font-mono font-bold text-slate-900">
                                        {{ number_format($p->price_per_litre, 2) }} ETB
                                    </td>
                                    <td class="access-table-td text-right font-mono text-slate-600">
                                        {{ number_format($p->opening_balance, 2) }} L
                                    </td>
                                    <td class="access-table-td text-right font-mono text-slate-600">
                                        {{ number_format($p->pipeline_stock, 2) }} L
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @endif

            <!-- 4. TRANSFER ORDERS -->
            @if($activeTable === 'transfer_orders')
                <div class="p-3 bg-slate-100 border-b border-slate-200 flex justify-between items-center text-xs">
                    <div>
                        <strong class="text-slate-800 text-sm">Table: transfer_orders</strong>
                        <span class="text-slate-500 ml-2">(MS Access legacy: <code>tblTODaily_history</code>)</span>
                    </div>
                    <span class="text-slate-600 font-mono font-semibold">{{ $orders->count() }} recorded orders</span>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-slate-200">
                        <thead>
                            <tr>
                                <th class="access-table-th">TO Number</th>
                                <th class="access-table-th">Reference</th>
                                <th class="access-table-th">Date</th>
                                <th class="access-table-th">Plate No</th>
                                <th class="access-table-th">Driver</th>
                                <th class="access-table-th text-right">Start Vol @ 20°C</th>
                                <th class="access-table-th text-right">Discharge Vol @ 20°C</th>
                                <th class="access-table-th text-right">Loss (L)</th>
                                <th class="access-table-th text-right">Debit (L)</th>
                                <th class="access-table-th text-right">Debit Amount</th>
                                <th class="access-table-th text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            @foreach($orders as $o)
                                <tr class="hover:bg-amber-50/50">
                                    <td class="access-table-td font-mono font-bold text-indigo-900">{{ $o->to_number }}</td>
                                    <td class="access-table-td font-mono text-slate-600">{{ $o->reference ?: '-' }}</td>
                                    <td class="access-table-td">{{ $o->order_date }}</td>
                                    <td class="access-table-td font-mono font-bold">{{ $o->plate_no }}</td>
                                    <td class="access-table-td font-bold text-slate-800">{{ $o->driver_name ?: '-' }}</td>
                                    <td class="access-table-td text-right font-mono">{{ number_format($o->start_vol20, 0) }} L</td>
                                    <td class="access-table-td text-right font-mono">{{ number_format($o->final_vol20, 0) }} L</td>
                                    <td class="access-table-td text-right font-mono font-bold text-rose-700">{{ number_format($o->loss_volume, 0) }} L</td>
                                    <td class="access-table-td text-right font-mono font-bold {{ $o->debit_volume > 0 ? 'text-rose-700' : 'text-emerald-700' }}">
                                        {{ number_format($o->debit_volume, 0) }} L
                                    </td>
                                    <td class="access-table-td text-right font-mono font-bold text-amber-800">
                                        {{ number_format($o->debit_amount, 2) }} ETB
                                    </td>
                                    <td class="access-table-td text-center">
                                        <a href="{{ route('petroleum.debit-note', $o->id) }}" class="px-2 py-0.5 rounded text-[11px] font-bold bg-indigo-100 text-indigo-800 hover:bg-indigo-200">
                                            Debit Note
                                        </a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @endif

            <!-- 5. DENSITY CORRECT 20 -->
            @if($activeTable === 'density_correct_20')
                <div class="p-3 bg-slate-100 border-b border-slate-200 flex justify-between items-center text-xs">
                    <div>
                        <strong class="text-slate-800 text-sm">Table: density_correct_20</strong>
                        <span class="text-slate-500 ml-2">(MS Access legacy: <code>Density_Correct_20</code> - 361 rows)</span>
                    </div>
                    <span class="text-slate-600 font-mono font-semibold">Showing 100 of {{ $tableCounts['density_correct_20'] }} rows</span>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-slate-200 font-mono">
                        <thead>
                            <tr>
                                <th class="access-table-th text-right">Observed Density (kg/m³)</th>
                                <th class="access-table-th text-right">Observed Temperature (°C)</th>
                                <th class="access-table-th text-right">Standard Density @ 20°C (kg/m³)</th>
                                <th class="access-table-th">Standard Formula</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            @foreach($densitySample as $d)
                                <tr class="hover:bg-amber-50/50">
                                    <td class="access-table-td text-right font-bold text-slate-800">{{ number_format($d->observed_density, 1) }}</td>
                                    <td class="access-table-td text-right text-amber-700 font-bold">{{ number_format($d->temperature, 1) }} °C</td>
                                    <td class="access-table-td text-right font-bold text-indigo-800">{{ number_format($d->density_20, 2) }}</td>
                                    <td class="access-table-td text-[11px] text-slate-500 font-sans">
                                        ASTM 54B/D Table 20 Conversion: <code>DensityCalc::density20({{ $d->observed_density }}, {{ $d->temperature }})</code>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @endif

            <!-- 6. FACTOR CORRECT 20 -->
            @if($activeTable === 'factor_correct_20')
                <div class="p-3 bg-slate-100 border-b border-slate-200 flex justify-between items-center text-xs">
                    <div>
                        <strong class="text-slate-800 text-sm">Table: factor_correct_20</strong>
                        <span class="text-slate-500 ml-2">(MS Access legacy: <code>Factor_Correct_20</code> - 361 rows)</span>
                    </div>
                    <span class="text-slate-600 font-mono font-semibold">Showing 100 of {{ $tableCounts['factor_correct_20'] }} rows</span>
                </div>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-slate-200 font-mono">
                        <thead>
                            <tr>
                                <th class="access-table-th text-right">Temperature (°C)</th>
                                <th class="access-table-th text-right">Density @ 20°C (kg/m³)</th>
                                <th class="access-table-th text-right">Volume Correction Factor (VCF)</th>
                                <th class="access-table-th">Standard Formula</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            @foreach($factorSample as $f)
                                <tr class="hover:bg-amber-50/50">
                                    <td class="access-table-td text-right text-amber-700 font-bold">{{ number_format($f->temperature, 1) }} °C</td>
                                    <td class="access-table-td text-right font-bold text-slate-800">{{ number_format($f->density_20, 2) }}</td>
                                    <td class="access-table-td text-right font-bold text-emerald-700">{{ number_format($f->factor, 6) }}</td>
                                    <td class="access-table-td text-[11px] text-slate-500 font-sans">
                                        ASTM VCF 20°C: <code>DensityCalc::vcf20({{ $f->density_20 }}, {{ $f->temperature }})</code>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @endif

        </div>

    </div>

</body>
</html>
